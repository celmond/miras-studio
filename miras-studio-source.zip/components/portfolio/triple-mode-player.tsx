"use client";
import { useEffect, useRef, useState } from "react";
import { copy, MODES, type Language, type Mode, type PortfolioCase } from "@/lib/portfolio";
import { subtitles } from "@/lib/subtitles";
import { Icon } from "./icons";

const formatTime = (seconds: number) => `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, "0")}`;
type Pending = { token: number; mode: Mode; time: number; play: boolean };

export function TripleModePlayer({ item, language }: { item: PortfolioCase; language: Language }) {
  const t = copy[language];
  const videos = useRef<Partial<Record<Mode, HTMLVideoElement>>>({});
  const shell = useRef<HTMLDivElement>(null);
  const selected = useRef<Mode>("before");
  const displayed = useRef<Mode>("before");
  const pending = useRef<Pending | null>(null);
  const serial = useRef(0);
  const playIntent = useRef(false);
  const position = useRef(0);
  const sound = useRef({ volume: 1, muted: false, rate: 1 });
  const [mode, setMode] = useState<Mode>("before");
  const [shown, setShown] = useState<Mode>("before");
  const [ready, setReady] = useState<Partial<Record<Mode, boolean>>>({});
  const [armed, setArmed] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [started, setStarted] = useState(false);
  const [time, setTime] = useState(0);
  const [volume, setVolume] = useState(1);
  const [muted, setMuted] = useState(false);
  const [rate, setRate] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const [captions, setCaptions] = useState(true);
  const [sources, setSources] = useState<Partial<Record<Mode, string>>>({});
  const scrubbing = useRef(false);
  const resumeAfterScrub = useRef(false);
  const cue = subtitles.find(c => time >= c.start && time < c.end);

  // Download complete files before making them seekable. Blob URLs avoid
  // host/CDN Range responses that can restart a remote MP4 at zero.
  useEffect(() => {
    if (!armed) return;
    const controller = new AbortController();
    const urls: string[] = [];
    Promise.all(MODES.map(async key => {
      const path = key === "music" ? "music-drama" : key;
      const response = await fetch(`${import.meta.env.BASE_URL}media/${item.id}-${path}.mp4`, { signal: controller.signal });
      if (!response.ok) throw new Error(`Media ${response.status}`);
      const blob = await response.blob();
      if (controller.signal.aborted) return null;
      const url = URL.createObjectURL(blob); urls.push(url);
      return [key, url] as const;
    })).then(entries => {
      if (!controller.signal.aborted) setSources(Object.fromEntries(entries.filter(e => e !== null)));
    }).catch(() => { if (!controller.signal.aborted) setError(true); });
    return () => { controller.abort(); urls.forEach(url => URL.revokeObjectURL(url)); };
  }, [armed, item.id]);

  useEffect(() => {
    const node = shell.current;
    if (!node) return;
    const observer = new IntersectionObserver(entries => {
      if (entries.some(e => e.isIntersecting)) { setArmed(true); observer.disconnect(); }
    }, { rootMargin: "350px" });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const stop = (event: Event) => {
      if ((event as CustomEvent<{ id: string }>).detail.id === item.id) return;
      playIntent.current = false;
      if (pending.current) pending.current.play = false;
      Object.values(videos.current).forEach(video => video?.pause());
      setPlaying(false);
    };
    window.addEventListener("miras:play", stop);
    const elements = videos.current;
    return () => { window.removeEventListener("miras:play", stop); Object.values(elements).forEach(v => v?.pause()); };
  }, [item.id]);

  function claimAudio() { window.dispatchEvent(new CustomEvent("miras:play", { detail: { id: item.id } })); }
  function applySound(video: HTMLVideoElement) {
    video.volume = sound.current.volume;
    video.muted = sound.current.muted;
    video.playbackRate = sound.current.rate;
  }
  function reveal(target: Mode) {
    const video = videos.current[target];
    const request = pending.current;
    if (!video || !request || request.mode !== target || request.token !== serial.current || video.seeking || video.readyState < 2) return;
    if (Math.abs(video.currentTime - request.time) > .12 && !request.play) return;
    displayed.current = target;
    setShown(target);
    setLoading(false);
    pending.current = null;
  }
  function playbackFailure(token: number) {
    if (token !== serial.current) return;
    playIntent.current = false;
    setPlaying(false);
    setLoading(false);
  }
  function switchMode(target: Mode) {
    if (target === selected.current || !ready[target]) return;
    const old = videos.current[selected.current];
    const video = videos.current[target];
    if (!video) return;
    const at = pending.current?.time ?? old?.currentTime ?? position.current;
    const shouldPlay = pending.current ? playIntent.current : !!old && !old.paused && !old.ended;
    playIntent.current = shouldPlay;
    const token = ++serial.current;
    pending.current = { token, mode: target, time: Math.min(at, item.duration), play: shouldPlay };
    selected.current = target;
    setMode(target); setError(false); setLoading(true);
    Object.entries(videos.current).forEach(([key, v]) => { if (v) { v.pause(); if (key !== target) v.muted = true; } });
    applySound(video);
    video.currentTime = Math.min(at, item.duration);
    position.current = at;
    if (shouldPlay) { claimAudio(); video.play().then(() => reveal(target)).catch(() => playbackFailure(token)); }
    else reveal(target);
  }
  function togglePlay() {
    const video = videos.current[selected.current];
    if (!video || !ready[selected.current]) return;
    if (playIntent.current) { playIntent.current = false; if (pending.current) pending.current.play = false; video.pause(); setPlaying(false); return; }
    if (video.ended || video.currentTime >= item.duration - .02) { video.currentTime = 0; position.current = 0; }
    playIntent.current = true; setStarted(true); setError(false); applySound(video); claimAudio();
    const token = serial.current;
    video.play().catch(() => playbackFailure(token));
  }
  function seek(value: number) {
    const video = videos.current[selected.current];
    if (!video) return;
    position.current = value; setTime(value); setStarted(true);
    if (pending.current) pending.current.time = value;
    video.currentTime = value;
  }
  function changeVolume(value: number) {
    sound.current.volume = value; sound.current.muted = value === 0;
    setVolume(value); setMuted(value === 0);
    const video = videos.current[selected.current]; if (video) applySound(video);
  }
  function toggleMute() {
    sound.current.muted = !sound.current.muted; setMuted(sound.current.muted);
    const video = videos.current[selected.current]; if (video) applySound(video);
  }
  function changeRate() {
    const next = rate === 1 ? 1.25 : rate === 1.25 ? 1.5 : rate === 1.5 ? 2 : 1;
    sound.current.rate = next; setRate(next);
    const video = videos.current[selected.current]; if (video) video.playbackRate = next;
  }
  function fullscreen() {
    if (document.fullscreenElement) { void document.exitFullscreen(); return; }
    if (shell.current?.requestFullscreen) { void shell.current.requestFullscreen().catch(() => {}); return; }
    const video = videos.current[selected.current] as (HTMLVideoElement & { webkitEnterFullscreen?: () => void }) | undefined;
    video?.webkitEnterFullscreen?.();
  }

  return <div ref={shell} className="player-shell" data-case={item.id} data-mode={mode}>
    <div className="video-viewport" onClick={togglePlay}>
      {MODES.map(key => <video key={key} ref={node => { if (node) videos.current[key] = node; }}
        className={`comparison-video ${shown === key ? "is-visible" : ""}`}
        src={sources[key]}
        poster={`${import.meta.env.BASE_URL}media/${item.id}-poster.jpg`} preload="metadata" playsInline controls={false}
        muted={key !== mode || muted} aria-label={`${item.title[language]} — ${t.modeNames[key].join(" / ")}`}
        onLoadedMetadata={event => { setReady(prev => ({ ...prev, [key]: true })); const video = event.currentTarget; if (key !== selected.current) { video.pause(); video.muted = true; } }}
        onLoadedData={() => reveal(key)} onCanPlay={() => reveal(key)} onSeeked={() => reveal(key)}
        onTimeUpdate={event => { if (key === selected.current && !scrubbing.current && !event.currentTarget.seeking) { position.current = event.currentTarget.currentTime; setTime(position.current); } }}
        onPlay={event => { if (event.currentTarget.paused) return; if (key !== selected.current) { event.currentTarget.pause(); event.currentTarget.muted = true; return; } playIntent.current = true; if (pending.current) pending.current.play = true; setStarted(true); claimAudio(); }}
        onVolumeChange={event => { if (key === selected.current) { sound.current.volume = event.currentTarget.volume; sound.current.muted = event.currentTarget.muted; setVolume(event.currentTarget.volume); setMuted(event.currentTarget.muted); } }}
        onRateChange={event => { if (key === selected.current) { sound.current.rate = event.currentTarget.playbackRate; setRate(event.currentTarget.playbackRate); } }}
        onPlaying={event => { if (key !== selected.current || !playIntent.current) { event.currentTarget.pause(); event.currentTarget.muted = true; return; } displayed.current = key; setShown(key); setPlaying(true); setStarted(true); setLoading(false); pending.current = null; claimAudio(); }}
        onPause={() => { if (key === selected.current && !pending.current && !scrubbing.current) { playIntent.current = false; setPlaying(false); } }}
        onEnded={() => { if (key === selected.current) { playIntent.current = false; setPlaying(false); setTime(item.duration); } }}
        onError={() => { if (key === selected.current && armed) { setError(true); setLoading(false); playIntent.current = false; setPlaying(false); } }}
      ><track kind="subtitles" src={`${import.meta.env.BASE_URL}media/wide-en.vtt`} srcLang="en" label="English" /><track kind="subtitles" src={`${import.meta.env.BASE_URL}media/wide-ru.vtt`} srcLang="ru" label="Русский" /></video>)}
      {captions && cue && <div className="video-captions" aria-hidden="true"><span>{cue[language]}</span></div>}
      {!started && <div className="poster-shade" />}
      {!playing && !loading && <button className="video-play" type="button" aria-label={`${t.playerPlay}: ${item.title[language]}`} disabled={!ready[mode]} onClick={event => { event.stopPropagation(); togglePlay(); }}><Icon name="play" size={25} /></button>}
      <span className="video-state-label"><span className={`state-dot ${mode === "before" ? "original" : ""}`} />{t.modeNames[mode][0]} <span> / {t.modeNames[mode][1]}</span></span>
      {loading && <div className="video-loading" role="status"><span className="small-spinner" />{t.loading}</div>}
    </div>
    <div className="player-controls">
      <button type="button" className="icon-button" onClick={togglePlay} disabled={!ready[mode]} aria-label={playing ? t.playerPause : t.playerPlay}><Icon name={playing ? "pause" : "play"} size={18} /></button>
      <span className="time-display">{formatTime(time)}</span>
      <input className="seek-range" type="range" min={0} max={item.duration} step={.01} value={Math.min(time, item.duration)} onPointerDown={event => { scrubbing.current = true; resumeAfterScrub.current = playIntent.current; event.currentTarget.setPointerCapture(event.pointerId); videos.current[selected.current]?.pause(); }}
        onPointerUp={event => { seek(Number(event.currentTarget.value)); scrubbing.current = false; if (resumeAfterScrub.current) { playIntent.current = true; void videos.current[selected.current]?.play().catch(() => playbackFailure(serial.current)); } }}
        onPointerCancel={() => { scrubbing.current = false; if (resumeAfterScrub.current) void videos.current[selected.current]?.play(); }}
        onChange={event => seek(Number(event.target.value))} aria-label={`${t.seek}: ${item.title[language]}`} disabled={!ready[mode]} style={{ "--progress": `${time / item.duration * 100}%` } as React.CSSProperties} />
      <span className="time-display total-time">{formatTime(item.duration)}</span>
      <button type="button" className="speed-button" onClick={changeRate} aria-label={`${t.speed}: ${rate}×`}>{rate}×</button>
      <button type="button" className="icon-button" onClick={toggleMute} aria-label={muted ? t.unmute : t.mute}><Icon name={muted || volume === 0 ? "muted" : "volume"} size={18} /></button>
      <input className="volume-range" type="range" min={0} max={1} step={.01} value={muted ? 0 : volume} onChange={event => changeVolume(Number(event.target.value))} aria-label={t.volume} />
      <button type="button" className={`caption-button ${captions ? "active" : ""}`} onClick={() => setCaptions(value => !value)} aria-pressed={captions} aria-label={language === "ru" ? "Субтитры" : "Subtitles"}>CC</button>
      <button type="button" className="icon-button" onClick={fullscreen} aria-label={t.fullscreen}><Icon name="fullscreen" size={18} /></button>
    </div>
    <div className="mode-area">
      <div className="mode-switch" role="group" aria-label={`${t.switchLabel}: ${item.title[language]}`}>
        {MODES.map((key, i) => <button key={key} type="button" className={`mode-button ${mode === key ? "active" : ""}`} aria-pressed={mode === key} onClick={() => switchMode(key)} disabled={!ready[key]}>
          <span className="mode-number">0{i + 1}</span><span className="mode-words"><strong>{t.modeNames[key][0]}</strong><small>{t.modeNames[key][1]}</small></span>
        </button>)}
      </div>
      <p className="switch-hint" aria-live="polite">{error ? t.loadError : t.switchHint}</p>
    </div>
  </div>;
}
