"use client";
import { useEffect, useRef, useState } from "react";
import { cases, copy, filmCredits, identity, type Language } from "@/lib/portfolio";
import { TripleModePlayer } from "./triple-mode-player";
import { Icon } from "./icons";

const wave = [16, 23, 35, 21, 41, 57, 37, 69, 88, 54, 30, 75, 100, 72, 47, 62, 89, 55, 36, 66, 82, 51, 31, 47, 69, 40, 25, 37, 22, 15];
export function PortfolioSite({ initialLanguage }: { initialLanguage: Language }) {
  const [language, setLanguage] = useState<Language>(initialLanguage);
  const t = copy[language];
  const contactDialog = useRef<HTMLDialogElement>(null);
  const previousOverflow = useRef("");
  const contactTitle = language === "ru" ? "Связаться со мной" : "Get in touch";
  function openContact() {
    if (contactDialog.current?.open) return;
    previousOverflow.current = document.body.style.overflow;
    contactDialog.current?.showModal();
    document.body.style.overflow = "hidden";
  }
  function closeContact() { contactDialog.current?.close(); }
  function restoreScroll() { document.body.style.overflow = previousOverflow.current; }
  useEffect(() => () => { if (contactDialog.current?.open) document.body.style.overflow = previousOverflow.current; }, []);
  useEffect(() => { document.documentElement.lang = language; }, [language]);
  function chooseLanguage(value: Language) {
    setLanguage(value);
    document.cookie = `miras-language=${value};path=/;max-age=31536000;SameSite=Lax`;
    try { localStorage.setItem("miras-language", value); } catch {}
  }
  return <>
    <a className="skip-link" href="#work">{language === "ru" ? "Перейти к примерам" : "Skip to work"}</a>
    <header className="site-header wrap">
      <a className="brand" href="#top" aria-label="Miras Studio"><span className="brand-mark" aria-hidden="true">m<span>.</span></span><span>Miras Studio</span></a>
      <nav className="main-nav" aria-label={language === "ru" ? "Основная навигация" : "Main navigation"}>{["work", "services", "contact"].map((id, i) => <a href={`#${id}`} key={id}>{t.nav[i]}</a>)}</nav>
      <div className="language-switch" role="group" aria-label={t.language}>{(["ru", "en"] as Language[]).map(value => <button type="button" key={value} aria-pressed={language === value} className={language === value ? "selected" : ""} onClick={() => chooseLanguage(value)}>{value.toUpperCase()}</button>)}</div>
    </header>
    <main id="top">
      <section className="hero wrap" aria-labelledby="hero-heading">
        <div className="hero-kicker"><span className="tiny-line" />{t.kicker}</div>
        <div className="hero-composition">
          <h1 id="hero-heading"><span>{t.heroLine1}</span><span>{t.heroLine2}</span><em>{t.heroLine3}</em></h1>
          <div className="hero-aside">
            <div className="sound-signature" aria-hidden="true"><div className="wave-bars">{wave.map((height, i) => <i key={i} style={{ height: `${height}%` }} />)}</div><span>VOICE / DETAIL / PRESENCE</span></div>
            <p className="hero-intro">{t.intro}</p>
            <a className="hero-listen-link" href="#work"><span className="hero-listen-label">{t.listen}</span><span className="hero-listen-arrow"><Icon name="diagonal" size={22} /></span></a>
          </div>
        </div>
        <div className="hero-bottom"><span>{t.heroNote}</span><div>{t.heroTags.map((tag, i) => <span key={tag}>{i > 0 && <i aria-hidden="true">·</i>}{tag}</span>)}</div><a href="#work" className="scroll-cue" aria-label={t.listen}>↓</a></div>
      </section>
      <section id="work" className="work-section wrap" aria-labelledby="work-heading">
        <div className="section-opening"><p className="eyebrow">{t.workEyebrow}</p><div className="section-heading-row"><h2 id="work-heading">{t.workTitle.split("\n").map((line, i) => <span key={i}>{line}</span>)}</h2><div className="section-introduction"><p>{t.workIntro}</p><span className="headphone-note"><Icon name="headphones" size={17} />{t.headphone}</span></div></div></div>
        <div className="case-list">{cases.map((item, i) => <article className="work-case" key={item.id}>
          <div className="case-heading"><div className="case-heading-main"><span className="case-index">0{i + 1}</span><div><p className="case-type">{item.angle[language]} <span>/ {String(item.duration).replace(".", language === "ru" ? "," : ".")} {language === "ru" ? "сек" : "sec"}</span></p><h3>{item.title[language]}</h3></div></div><p className="case-description">{item.description[language]}</p></div>
          <TripleModePlayer item={item} language={language} />
          <div className="case-footnote"><span>{t.practice}</span><span>{t.noMusic}</span></div>
        </article>)}</div>
      </section>
      <section id="services" className="services-section wrap" aria-labelledby="services-heading">
        <p className="eyebrow">{t.servicesEyebrow}</p><div className="services-top"><h2 id="services-heading">{t.servicesTitle.split("\n").map((line, i) => <span key={i}>{line}</span>)}</h2><p className="about-note">{t.about}</p></div>
        <div className="services-list">{t.services.map((service, i) => <article className="service" key={i}><span className="service-index">0{i + 1}</span><h3>{service.title}</h3><p>{service.text}</p><span className="service-plus" aria-hidden="true"><Icon name="plus" size={19} /></span></article>)}</div>
      </section>
      <section id="contact" className="contact-section wrap" aria-labelledby="contact-heading">
        <p className="eyebrow">{t.contactEyebrow}</p><div className="contact-layout"><h2 id="contact-heading">{t.contactTitle.split("\n").map((line, i) => <span key={i}>{line}</span>)}</h2><div className="contact-aside"><p>{t.contactText}</p><button className="hero-listen-link contact-capsule" type="button" onClick={openContact} aria-haspopup="dialog"><span className="hero-listen-label">{t.emailAction}</span><span className="hero-listen-arrow"><Icon name="diagonal" size={22} /></span></button></div></div>
      </section>
    </main>
    <footer className="site-footer wrap"><div className="footer-top"><a className="brand" href="#top"><span className="brand-mark" aria-hidden="true">m<span>.</span></span><span>Miras Studio</span></a><p>{identity.name}<br /><span>{t.footer}</span></p></div>
      <details className="credits"><summary>{t.credits}<span aria-hidden="true">+</span></summary><div className="credits-body"><div><p>{t.creditsIntro}</p><p>{t.audioWork}</p><a href="https://cinestudy.org/2019/01/28/restaurant-scene/" target="_blank" rel="noreferrer">{t.sourceProject} ↗</a><pre>{filmCredits}</pre></div><div><h3>{t.musicCredit}</h3><p>“Heartbreaking” — Kevin MacLeod (incompetech.com)</p><p>Licensed under Creative Commons: By Attribution 4.0 License.</p><a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noreferrer">CC BY 4.0 ↗</a><br /><a href="https://www.incompetech.com/music/royalty-free/index.html?isrc=USUAN1100208" target="_blank" rel="noreferrer">Heartbreaking ↗</a><p>{t.changes}</p></div></div></details>
      <div className="footer-bottom"><span>© {new Date().getFullYear()} {t.copyright}</span><a href="#top">{language === "ru" ? "Наверх" : "Back to top"} ↑</a></div>
    </footer>
    <dialog ref={contactDialog} className="contact-dialog" aria-labelledby="contact-dialog-title" onClose={restoreScroll} onClick={event => {
      if (event.target !== event.currentTarget) return;
      const box = event.currentTarget.getBoundingClientRect();
      if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) closeContact();
    }}>
      <div className="contact-sheet">
        <div className="contact-sheet-heading"><span className="eyebrow">MIRAS STUDIO</span><button className="contact-close" type="button" onClick={closeContact} aria-label={language === "ru" ? "Закрыть" : "Close"} autoFocus>×</button></div>
        <h2 id="contact-dialog-title">{contactTitle}</h2>
        <p className="contact-sheet-intro">{language === "ru" ? "Выберите удобный способ — откроется чат или новое письмо." : "Choose a channel to open a chat or compose an email."}</p>
        <div className="contact-channels">
          <a href={`https://t.me/${identity.telegram}`} target="_blank" rel="noopener noreferrer"><span className="channel-icon" aria-hidden="true">↗</span><span><strong>Telegram</strong><small>@{identity.telegram}</small></span><Icon name="diagonal" size={22} /></a>
          <a href={`https://wa.me/${identity.whatsapp}`} target="_blank" rel="noopener noreferrer"><span className="channel-icon" aria-hidden="true">↗</span><span><strong>WhatsApp</strong><small>+7 771 546 08 40</small></span><Icon name="diagonal" size={22} /></a>
          <a href={`mailto:${identity.email}`}><span className="channel-icon" aria-hidden="true">@</span><span><strong>Gmail</strong><small>{identity.email}</small></span><Icon name="diagonal" size={22} /></a>
        </div>
        <p className="contact-sheet-note">{language === "ru" ? "Расскажите о задаче и приложите короткий фрагмент записи." : "Tell me about your project and include a short recording."}</p>
      </div>
    </dialog>
  </>;
}
