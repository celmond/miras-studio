export const subtitles = [
  {
    "start": 0.67,
    "end": 2.12,
    "en": "Hey, sorry I’m late.",
    "ru": "Привет. Извини, я опоздал."
  },
  {
    "start": 2.51,
    "end": 3.25,
    "en": "It’s okay.",
    "ru": "Ничего страшного."
  },
  {
    "start": 5.05,
    "end": 7.85,
    "en": "So, what’s good here?",
    "ru": "Ну, что здесь вкусного?"
  },
  {
    "start": 8.07,
    "end": 10.5,
    "en": "Listen, we need to talk.",
    "ru": "Послушай, нам нужно поговорить."
  },
  {
    "start": 11.76,
    "end": 12.6,
    "en": "What is it?",
    "ru": "Что случилось?"
  },
  {
    "start": 13.38,
    "end": 14.7,
    "en": "I know you cheated on me.",
    "ru": "Я знаю, что ты мне изменил."
  },
  {
    "start": 15.04,
    "end": 17.3,
    "en": "Our specials tonight are the…",
    "ru": "Сегодня у нас особое блюдо —"
  },
  {
    "start": 17.62,
    "end": 19.35,
    "en": "…crab-stuffed filet mignon…",
    "ru": "филе-миньон, фаршированный крабом,"
  },
  {
    "start": 19.35,
    "end": 21.45,
    "en": "…with a whiskey peppercorn sauce, or—",
    "ru": "с перечным соусом на виски, или…"
  },
  {
    "start": 22.46,
    "end": 24.5,
    "en": "We need a minute.",
    "ru": "Дайте нам минутку."
  },
  {
    "start": 25.45,
    "end": 26.4,
    "en": "A minute?",
    "ru": "Минутку?"
  }
] as const;
