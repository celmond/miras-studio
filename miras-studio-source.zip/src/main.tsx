import React from "react";
import { createRoot } from "react-dom/client";
import { PortfolioSite } from "../components/portfolio/portfolio-site";
import "./styles.css";
let language: "ru" | "en" = "ru";
try { if (localStorage.getItem("miras-language") === "en") language = "en"; } catch {}
document.documentElement.lang = language;
createRoot(document.getElementById("root")!).render(<PortfolioSite initialLanguage={language} />);
